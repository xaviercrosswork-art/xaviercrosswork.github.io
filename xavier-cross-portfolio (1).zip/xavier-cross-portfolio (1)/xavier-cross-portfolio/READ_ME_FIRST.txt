INFO1005 WEBSITE DESIGN — MODULE 2.3
BART SIMPSON ADVANCED BOOTSTRAP — CODE-FIRST BUILD

Module 2.2 skills are already built into the starter:
- responsive navbar
- Bootstrap grid
- responsive images
- progress bars
- custom CSS

Your Module 2.3 job:
1. Open the whole folder in Visual Studio Code.
2. Open index.html and css/custom.css.
3. Search for STEP and TODO_.
4. Build the Bootstrap carousel.
5. Build responsive cards and activate the modal.
6. Build the accordion.
7. Complete the advanced custom CSS tasks.
8. Save -> refresh -> test after every small change.
9. Search for TODO_ when finished. There should be none in index.html.
10. Validate index.html and css/custom.css.

FOCUS:
HTML = meaningful content and component structure.
Bootstrap = responsive layout and interactive component behaviour.
Custom CSS = brand, typography, sizing, image treatment and visual identity.
